/*  servo.h  */

void Servo_Init(unsigned int);
void Servo_Calib(void);
void Servo_GoTo(unsigned int);
void Servo_Step(void);

