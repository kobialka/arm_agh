struct sWatch {
	unsigned char ucMinutes, ucSeconds;
	unsigned char fSecondsValueChanged, fMinutesValuedChanged;
};


void WatchUpdate(void);

