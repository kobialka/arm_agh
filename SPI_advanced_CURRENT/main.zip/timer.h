// SPI Advanced KOBIALKA

/*  timer.h  */


void InitTimer0(void);
void WaitOnTimer0(unsigned int);
void InitTimer0Match0(unsigned int uiDelayTime);
void WaitOnTimer0Match0(void);



